package com.example.ntg_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NtgBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
