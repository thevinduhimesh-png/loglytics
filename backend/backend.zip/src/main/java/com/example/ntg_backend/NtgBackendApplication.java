package com.example.ntg_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NtgBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(NtgBackendApplication.class, args);
	}

}
